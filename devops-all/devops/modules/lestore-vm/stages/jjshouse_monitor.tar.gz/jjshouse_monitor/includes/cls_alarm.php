<?php
require_once(ROOT_PATH . "includes/phpmailer/class.phpmailer.php");

class Alarm {
    private $mail;
    
    public function Alarm() {
        $this->mail = new PHPMailer(true);
        $this->mail->IsSendmail();
        $this->mail->CharSet='UTF-8';
    }
    
    /**
     * 使用mail命令
     *
     */
    public function isMail() {
        if ($this->mail) {
            $this->mail->IsMail();
        }
    }
    
    public function sendmail($level, $subject, $content, $address_list, $is_html = false, $attachment_list = null) {
        $pre = $this->get_pre_subject($level);
        $hostname = `hostname`;
        $this->mail->Subject = "{$pre} {$subject} {$hostname}";
        $this->mail->SetFrom('noreply@i9i8.com', 'noreply');
        $this->mail->IsHTML($is_html);
        
        foreach ($address_list as $address => $name) {
            $this->mail->AddAddress($address, $name);
        }
        $time = date("Y-m-d H:i:s O");
        $this->mail->Body = "{$content} \ntime:{$time}\n";
        
        if (!empty($attachment_list)) {
            foreach ($attachment_list as $path => $name) {
                $this->mail->AddAttachment($path, $name);
            }
        }
        
        $this->mail->send();
    }
    
    /**
     * 根据等级返回邮件前缀
     *
     * @param mix $level
     * @return string
     */
    private function get_pre_subject($level) {
        switch ($level) {
        	case 1:
        	case 2:
        	case 3:
        	    $pre = "[Sev-{$level}]";
        	    break;
        	case "r":
        	    $pre = "[R_R]";
        	    break;
        	default:
        	    $pre = "";
        		break;
        }
        return $pre;
    }
}