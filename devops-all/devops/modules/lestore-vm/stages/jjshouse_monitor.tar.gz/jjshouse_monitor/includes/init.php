<?php

define('ROOT_PATH', str_replace('includes/init.php', '', str_replace('\\', '/', __FILE__)));