<?php

class CurlUtil {
    private $url;
    private $request_headers;
    private $timeout;
    private $username;
    private $password;
    private $ch;
    private $content;
    private $response_headers;

    public function CurlUtil($url, $request_headers = null, $timeout = 30, $username = null, $password = null) {
        $this->url = $url;
        $this->request_headers = $request_headers;
        $this->timeout = $timeout;
        $this->username = $username;
        $this->password = $password;
        $this->ch = curl_init($this->url);
        if ($this->request_headers) {
            curl_setopt($this->ch, CURLOPT_HTTPHEADER, $this->request_headers);
        }

        curl_setopt($this->ch, CURLOPT_USERPWD, $this->username.":".$this->password);	
        curl_setopt($this->ch, CURLOPT_TIMEOUT, $this->timeout);
        curl_setopt($this->ch, CURLOPT_CONNECTTIMEOUT, $this->timeout);

        curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($this->ch, CURLOPT_USERAGENT, "__monitor__");
        curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, 1);        
    }
    
    public function curl_setopt($key, $value) {
        curl_setopt($this->ch, $key, $value);
    }

    public function execute() {
        curl_setopt($this->ch, CURLOPT_HEADER, 1);
        $result = curl_exec($this->ch);
        $result_parts = explode("\n\r", $result);
        if (count($result_parts) > 1) {
            $this->response_headers = $result_parts[0];
            $this->content = '';    
            for($i=0; $i<count($result_parts); $i++) {
                if ($i > 0) {
                    $this->content.=$result_parts[$i];
                }
            }
        } else {
            $this->content = $result_parts[0];
        }
    }
    
    public function close() {
        curl_close($this->ch);
    }
    
    public function get_http_code() {
        $http_code = curl_getinfo($this->ch, CURLINFO_HTTP_CODE);
        return $http_code;
    }
    
    public function get_content() {
        return $this->content;
    }
    
    public function get_response_headers() {
        return $this->response_headers;
    }
    
    public function get_errno() {
        return curl_errno($this->ch);
    }
    
    public function get_error() {
        return curl_error($this->ch);
    }
    
    public function get_url() {
        return $this->url;
    }

}
