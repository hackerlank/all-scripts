<?php
/**
 * 检查是否有5xx返回内容
 */
include_once("includes/init.php");
include_once(ROOT_PATH . "log/cls_log_checker.php");
error_reporting(E_ALL & ~E_NOTICE);

$log_file_list = array(
    "jjshouse_log" => "/opt/data1/nginxlogs/access-je-prod-www.log",
);


echo "run at " . date('Y-m-d H:i:s') . "\n";
$log_checker = new LogChecker($log_file_list);
$log_checker->add_log_checker("ReportLogChecker");

echo "check at " . date('Y-m-d H:i:s') . "\n";
$log_checker->check();

echo "report at " . date('Y-m-d H:i:s') . "\n";
$log_checker->report();

echo "clear at " . date('Y-m-d H:i:s') . "\n";
$log_checker->clear();

echo "end at " . date('Y-m-d H:i:s') . "\n";
