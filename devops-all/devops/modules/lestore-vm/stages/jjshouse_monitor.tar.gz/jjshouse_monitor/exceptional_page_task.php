<?php
/**
 * 检查日志中访问小于100字节的小文件
 */
include_once("includes/init.php");
include_once(ROOT_PATH ."includes/cls_alarm.php");

$logfile = $argv[1];
if (is_file($logfile)) {
    $pathinfo = pathinfo($logfile);
    $tmpfile = "/tmp/{$pathinfo['basename']}.csv";
} else {
    echo date('Y-m-d H:i:s') . ": log file error \"$logfile\"";
    die();
}

$mail_list = array("lchen@i9i8.com" => "陈磊", "ychen@leqee.com" => "陈翼", 'jhshi@i9i8.com' => '施剑辉');
echo "run at " . date('Y-m-d H:i:s') . ", logfile {$logfile}\n";

$counter_map = array();

$fp = fopen($logfile, "r");
while ($fp && !feof($fp)) {
    $line = fgets($fp);
    $parts = explode(' ', $line);
    if ($parts[9] < 100 && $parts[5] == "\"GET" && !in_array($parts[8], array(302, 206, 304)) && strpos($line, 'Googlebot') === false 
        && strpos($parts[6], '/ajax.php') !== strlen($parts[6]) - 9
        && strpos($parts[6], '/newsletter_act.php') !== 0
        && strpos($parts[6], '/version') !== 0
        && strpos($parts[6], '/crossdomain.xml') !== 0
        && strpos($parts[6], '/error.php') !== 0
        && strpos($parts[6], '/thefind_') !== 0
        && strpos($parts[6], '/spacer.gif') === false
        ) {
        $counter_map[$parts[6]]++;
    }
}
fclose($fp);


$fp = fopen($tmpfile, "w+");
foreach ($counter_map as $url => $count) {
    fwrite($fp, "\"{$count}\",\"{$url}\"\n");
}
fclose($fp);

$alarm = new Alarm();

echo "send email at " . date('Y-m-d H:i:s') . "\n";
$alarm->sendmail("r", '字节数较小页面', '内容见附件', $mail_list, false, array($tmpfile => "{$pathinfo['basename']}.csv"));

unlink($tmpfile);
echo "end at " . date('Y-m-d H:i:s') . "\n";