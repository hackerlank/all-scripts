<?php
/**
 * 监控文件
 * a. 是否连接超时
 * b. 首页大小是否大于5K
 * c. 首页是否包含CSS文件
 * d. CSS文件大小是否大于1K
 * 
 */
include_once("includes/init.php");
include_once(ROOT_PATH . "index/cls_index_checker.php");
include_once(ROOT_PATH . "includes/cls_alarm.php");

echo "run at " . date('Y-m-d H:i:s') . "\n";

$url_list = array(
    "http://east.jjshouse.com" => 2,
    "http://www.jjshouse.com" => 1,
    "http://us-east-fe-1.jjshouse.com" => 1,
    "http://us-east-fe-2.jjshouse.com" => 1,
    "http://east.jenjenhouse.com" => 2,
    "http://www.jenjenhouse.com" => 1,
    "http://us-east-fe-1.jenjenhouse.com" => 1,
    "http://us-east-fe-2.jenjenhouse.com" => 1,
//暂时做压力测试使用    "http://us-east-fe-3.jenjenhouse.com" => 1,
    "http://us-east-fe-4.jenjenhouse.com" => 1,
    "http://east.jennyjoseph.com" => 2,
    "http://www.jennyjoseph.com" => 1,
    "http://us-east-fe-1.jennyjoseph.com" => 1,
    "http://us-east-fe-2.jennyjoseph.com" => 1,
//暂时做压力测试使用    "http://us-east-fe-3.jennyjoseph.com" => 1,
    "http://us-east-fe-4.jennyjoseph.com" => 1,
    "http://east.amormoda.com" => 2,
    "http://www.amormoda.com" => 1,
    "http://us-east-fe-1.amormoda.com" => 1,
    "http://us-east-fe-2.amormoda.com" => 1,
//暂时做压力测试使用   "http://us-east-fe-3.amormoda.com" => 1,  
    "http://www.jjshouse.com/A-line-Princess-V-neck-Knee-length-Chiffon--Charmeuse-Bridesmaid-Dresses-With-Ruffle--Beading-007004117-g4117" => 1,
    "http://www.jjshouse.com/Empire-Sweetheart-Floor-length-Chiffon--Charmeuse-Holiday-Dresses-With-Ruffle--Beading-020003246-g3246" => 1,
    "http://www.jjshouse.com/A-line-Princess-V-neck-Short-Mini-Chiffon--Charmeuse-Homecoming-Dresses-With-Ruffle--Beading-022004341-g4341" => 1,
    "http://www.jenjenhouse.com/A-line-Princess-V-neck-Short-Mini-Chiffon--Charmeuse-Homecoming-Dresses-With-Ruffle--Beading-022004341-g4341" => 1,
    "http://www.jenjenhouse.com/Empire-Sweetheart-Floor-length-Chiffon--Charmeuse-Holiday-Dresses-With-Ruffle--Beading-020003246-g3246" => 1,
    "http://www.jenjenhouse.com/Mermaid-Sweetheart-Chapel-Train-Charmeuse-Holiday-Dresses-With-Ruffle--Beading-020003237-g3237" => 1,
);

$mail_list = array(
    "alarm@i9i8.com" => "alarm",
    "ychen@leqee.com" => "陈翼",
    "yzhang@i9i8.com" => "张勇",
    "lchen@i9i8.com" => "陈磊",
    "jhshi@i9i8.com" => "施剑辉",
);

$alarm = new Alarm();

foreach ($url_list as $url => $level) {
    $failed_count = 0;
    $succeed = false;
    while ($failed_count < 3){
        $index_checker = new IndexChecker($url);
        $index_checker->check_all();
        if (!$index_checker->get_result()) {
            $failed_count += 1;
        } else {
            $succeed = true;
            break;
        }
    }
    if ($succeed){
        print_r($url . " OK\n");
    } else {
        $content = $index_checker->print_result(true);
        print_r($url . " error\n");
        print_r($content);
        $alarm->sendmail($level, "{$url}访问异常", $content, $mail_list);
    }
}

echo "end at " . date('Y-m-d H:i:s') . "\n";