<?php
/**
 * 监控文件
 * a. 是否连接超时
 * b. 首页大小是否大于5K
 * c. 首页是否包含CSS文件
 * d. CSS文件大小是否大于1K
 * 
 */
include_once("includes/init.php");
include_once(ROOT_PATH . "index/cls_url_checker.php");
include_once(ROOT_PATH . "includes/cls_alarm.php");

echo "run at " . date('Y-m-d H:i:s') . "\n";

$url_list = array(
    "https://s3.amazonaws.com/jjsresource/themes/fashion/css/all_97.css" => 1,
    "https://s3.amazonaws.com/jjsresource/themes/fashion/js/all.js" => 1,
);

$mail_list = array(
    "alarm@i9i8.com" => "alarm",
    "ychen@leqee.com" => "陈翼",
    "yzhang@i9i8.com" => "张勇",
    "lchen@i9i8.com" => "陈磊",
    "jhshi@i9i8.com" => "施剑辉",
);

$alarm = new Alarm();

foreach ($url_list as $url => $level) {
    $failed_count = 0;
    $succeed = false;
    while ($failed_count < 3){
        $index_checker = new UrlChecker($url);
        $index_checker->check_all();
        if (!$index_checker->get_result()) {
            $failed_count += 1;
        } else {
            $succeed = true;
            break;
        }
    }
    if ($succeed){
        print_r($url . " OK\n");
    } else {
        $content = $index_checker->print_result(true);
        print_r($url . " error\n");
        print_r($content);
        $alarm->sendmail($level, "{$url}访问异常", $content, $mail_list);
    }
}

echo "end at " . date('Y-m-d H:i:s') . "\n";
