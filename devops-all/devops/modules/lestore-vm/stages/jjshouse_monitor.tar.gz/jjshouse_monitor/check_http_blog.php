<?php
/**
 * 监控文件
 * a. 是否连接超时
 * 
 */
include_once("includes/init.php");
include_once(ROOT_PATH . "index/cls_blog_checker.php");
include_once(ROOT_PATH . "includes/cls_alarm.php");

echo "run at " . date('Y-m-d H:i:s') . "\n";

$url_list = array(
    "http://www.chiffon-bridesmaid-dresses.com" => 2,
    "http://www.cheap-bridesmaid-dress.com" => 2,
    "http://www.weddingdressreview.com" => 2,
);

$mail_list = array(
    "ychen@leqee.com" => "陈翼",
    "yzhang@i9i8.com" => "张勇",
    "lchen@i9i8.com" => "陈磊",
    "jhshi@i9i8.com" => "施剑辉",
);

$alarm = new Alarm();

foreach ($url_list as $url => $level) {
    $failed_count = 0;
    $succeed = false;
    while ($failed_count < 3){
        $blog_checker = new BlogChecker($url);
        $blog_checker->check_all();
        if (!$blog_checker->get_result()) {
            $failed_count += 1;
        } else {
            $succeed = true;
            break;
        }
    }
    if ($succeed){
        print_r($url . " OK\n");
    } else {
        $content = $blog_checker->print_result(true);
        print_r($url . " error\n");
        print_r($content);
        $alarm->sendmail($level, "{$url}访问异常", $content, $mail_list);
    }
}

echo "end at " . date('Y-m-d H:i:s') . "\n";
