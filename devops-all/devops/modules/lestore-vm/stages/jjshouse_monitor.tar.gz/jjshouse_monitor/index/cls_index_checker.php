<?php
/**
 * 首页检查各项指标，会针对一个url进行一次页面抓取，然后分析结果
 * 
 * 所有的check都以true成功，false失败
 */
include_once(ROOT_PATH . "includes/cls_curl_util.php");

class IndexChecker {
    private $dir = "/var/log/checker";
    private $curl_util;
    private $result_map = array();

    public function IndexChecker($url) {
        $this->curl_util = new CurlUtil($url);
        $this->curl_util->execute();
    }

    public function check_all() {
        $this->result_map['timeout'] = $this->check_time_out();
        $this->result_map['size'] = $this->check_size();
        $this->result_map['css'] = $this->check_css();
    }

    public function get_result_map() {
        return $this->result_map;
    }

    public function print_result($return = false) {
        $result = "";
        foreach ($this->result_map as $name => $value) {
            $result .= "{$name}: " . ($value['result'] ? "OK" : "FAILED") . "\n";
            if (!$value['result']) {
                $result .= print_r($value, true);
                $result .= "\n";
            }
        }
        return print_r($result, $return);
    }

    /**
     * 检查所有的监控是否都正常
     *
     * @return unknown
     */
    public function get_result() {
        $result = true;
        foreach ($this->result_map as $name => $value) {
            $result &= $value['result'];
        }
        if (!$result) {
            $this->result_map['google_timeout'] = $this->check_google();
            if (!$this->result_map['google_timeout'] ['result']) {  
                $result = true;
            }
        }
        return $result;
    }

    public function close() {
        $this->curl_util->close();
    }

    /**
     * 检查是否超时
     * curl错误 
     * 6 无法解析主机
     * 7 无法解析域名
     * 28 超时
     *
     * @return boolean
     */
    public function check_time_out() {
        $result = array();
        if (in_array($this->curl_util->get_errno(), array(7, 28))) {
            $result['result'] = false;
            $result['error'] = $this->curl_util->get_error();
            $result['errno'] = $this->curl_util->get_errno();
        } else {
            $result['result'] = true;
        }
        return $result;
    }

    public function check_google() {
        $result = array();
        $google_url = "http://www.google.com";
        $ch = new CurlUtil($google_url);
        $ch->execute();
        if (in_array($ch->get_errno(), array(6, 7, 28))) {
            $result['result'] = false;
            $result['error'] = $ch->get_error();
            $result['errno'] = $ch->get_errno();
        } else {
            $result['result'] = true;
        }

        $ch->close();
        return $result;
    }

    /**
     * 检查css文件
     *
     * @param int $size
     * @return boolean
     */
    public function check_css($size = 1024) {
        $result = array();
        $css_url = $this->find_css();
        if ($css_url == null) {
            $this->save_file("css_" . date('H:i:s'), "<!--{$this->curl_util->get_url()}-->\n{$this->curl_util->get_content()}");
            $result['result'] = false;
            return $result;
        }
        $ch = new CurlUtil($css_url);
        $ch->execute();
        $css_content = $ch->get_content();
        if (strlen($css_content) >= 1024) {
            $result['result'] = true;
        } else {
            $this->save_file("css_" . date('H:i:s'), "{$css_url}\n{$css_content}");
            $result['result'] = false;
            $result['content'] = $css_content;
            $result['url'] = $css_url;
            $result['error'] = $ch->get_error();
            $result['errno'] = $ch->get_errno();
        }

        $ch->close();
        return $result;
    }

    /**
     * 检查首页大小
     *
     * @param int $size
     * @return boolean
     */
    public function check_size($size = 5120) {
        $result = array();
        $content = $this->curl_util->get_content();
        if (strlen($content) >= $size) {
            $result['result'] = true;
        } else {
            $this->save_file("index_" . date('His'), "{$this->curl_util->get_url()}\n{$content}");
            $result['result'] = false;
            $result['content'] = $content;
            $result['url'] = $this->curl_util->get_url();
            $result['error'] = $this->curl_util->get_error();
            $result['errno'] = $this->curl_util->get_errno();            
        }
        
        return $result;
    }

    /**
     * 从首页查找css文件
     *
     * @return string
     */
    private function find_css() {
        $pattern = '/<link href="(.*?\.css.*?)"/s';
        $matches = array();
        if (preg_match($pattern, $this->curl_util->get_content(), $matches)) {
            return trim($matches[1]);
        } else {
            return null;
        }
    }

    private function save_file($filename, $content) {
        $path = $this->dir . "/" . date('Y-m-d');
        if (!is_dir($path)) {
            mkdir($path);
        }
        $fp = fopen($path . "/" . $filename , "w+");
        fwrite($fp, $content);
        fclose($fp);
    }
}
