<?php
/**
 * 监控文件
 * a. 是否连接超时
 * b. 访问页面是否异常
 * 
 */
include_once("includes/init.php");
include_once(ROOT_PATH . "index/cls_cms_checker.php");
include_once(ROOT_PATH . "includes/cls_alarm.php");
include_once(ROOT_PATH . "includes/config.php");

echo "run at " . date('Y-m-d H:i:s') . "\n";

$url_list = array(
    "https://cms.jjshouse.com/version" => 1,
    "https://cms.jenjenhouse.com/version" => 1,
    "https://t.jjshouse.com/osticket/version" => 2,
    "https://t.jenjenhouse.com/osticket/version" => 2,
);

$mail_list = array(
    "ychen@leqee.com" => "陈翼",
    "yzhang@i9i8.com" => "张勇",
    "lchen@i9i8.com" => "陈磊",
    "jhshi@i9i8.com" => "施剑辉",
);

$alarm = new Alarm();

foreach ($url_list as $url => $level) {
    $failed_count = 0;
    $succeed = false;
    while ($failed_count < 3){
        $cms_checker = new CmsChecker($url, $username, $password);
        $cms_checker->check_https_cms();
        if (!$cms_checker->get_result()) {
            $failed_count += 1;
        } else {
            $succeed = true;
            break;
        }
    }
    if ($succeed){
        print_r($url . " OK\n");
    } else {
        $content = $cms_checker->print_result(true);
        print_r($url . " error\n");
        print_r($content);
        $alarm->sendmail($level, "{$url}访问异常", $content, $mail_list);
    }
}

echo "end at " . date('Y-m-d H:i:s') . "\n";