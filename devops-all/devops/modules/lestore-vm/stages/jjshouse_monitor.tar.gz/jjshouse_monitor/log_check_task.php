<?php
/**
 * 检测日志任务
 */
include_once("includes/init.php");
include_once(ROOT_PATH . "log/cls_log_checker.php");

$date = $argv[1];
$log_file_list = array(
    "JS_east1" => "/mnt/backup/jjshouse/nginxlogs_jjshouse_east1/nginxlogs/access-{$date}-jjshouse-www.log",
    "JS_east2" => "/mnt/backup/jjshouse/nginxlogs_jjshouse_east2/nginxlogs/access-{$date}-jjshouse-www.log",
    "JE_east1" => "/mnt/backup/jenjenhouse/nginxlogs_jenjenhouse_east1/nginxlogs/access-{$date}-jenjenhouse-www.log",
    "JE_east2" => "/mnt/backup/jenjenhouse/nginxlogs_jenjenhouse_east2/nginxlogs/access-{$date}-jenjenhouse-www.log",
);


echo "run at " . date('Y-m-d H:i:s') . ", date {$date}\n";
$log_checker = new LogChecker($log_file_list);
$log_checker->add_log_checker("LittlePageLogChecker");

echo "check at " . date('Y-m-d H:i:s') . "\n";
$log_checker->check();

echo "report at " . date('Y-m-d H:i:s') . "\n";
$log_checker->report();

echo "clear at " . date('Y-m-d H:i:s') . "\n";
$log_checker->clear();

echo "end at " . date('Y-m-d H:i:s') . "\n";