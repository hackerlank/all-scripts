<?php
/**
 * 检测日志文件小于500的文件
 *
 */

include_once(ROOT_PATH . "log/cls_abstract_log_checker.php");

class LittlePageLogChecker extends AbstractLogChecker {

    protected $report_mail_list = array(
#        'lchen@i9i8.com' => '陈磊',
#        'ychen@leqee.com' => '陈翼',
#        'yzhang@i9i8.com' => '张勇',
        'jhshi@i9i8.com' => '施剑辉',
    );
    
    public function check($line, $log_file_key) {
        $log_file = $this->log_file_list[$log_file_key];
        $parts = explode(' ', $line);
        if ($parts[9] < 100     // 文件大小小于100字节
            && $parts[5] == "\"GET"  // get请求
            && !in_array($parts[8], array(302, 206, 304))  // response code例外
            && strpos($line, 'Googlebot') === false     // 去除google爬虫
            && strpos($parts[6], '/ajax.php') !== strlen($parts[6]) - 9 // 不以ajax.php的请求结尾，正常的请求都带参数
            && strpos($parts[6], '/newsletter_act.php') !== 0   // newsletter空白图片
            && strpos($parts[6], '/version') !== 0  // 版本信息
            && strpos($parts[6], '/crossdomain.xml') !== 0  // 非页面
            && strpos($parts[6], '/BingSiteAuth.xml') !== 0  // 非页面
            && strpos($parts[6], '/error.php') !== 0    // 正常错误页面是带参数的
            && strpos($parts[6], '/spacer.gif') === false   // 空白图片
            && strpos($parts[6], '/osticket') === false   // osticket
        ) {
            $this->result_map[$log_file][$parts[6]]++;
        }
    }
    
    protected function get_report_content() {
        $report_content = "";
        foreach ($this->log_file_list as $log_file) {
            $total_count = 0;
            $cart_count = 0;
            $checkout_count = 0;
            if (is_array($this->result_map[$log_file])) {
                foreach ($this->result_map[$log_file] as $url => $count) {
                    // 计数不包含/review的计数
                    if (strpos($url, "/review") === false) {
                        $total_count += $count;    
                    }
                    if (strpos($url, "/cart.php") !== false) {
                        $cart_count += $count;
                    }
                    if (strpos($url, "/checkout.php") !== false) {
                        $checkout_count += $count;
                    }                
                }
            }
            
            $report_content .= "$log_file\n";
            $report_content .= "不包含review的总数: {$total_count}\n";
            $report_content .= "/cart数目: {$cart_count}\n";
            $report_content .= "/checkout数目: {$checkout_count}\n";
            $report_content .= "\n\n";
        }

            
        return $report_content;
    }
    
    protected function get_tmp_file_content($log_file_key) {
        $tmp_file_content = "";
        $log_file = $this->log_file_list[$log_file_key];
        if (is_array($this->result_map[$log_file])) {
            foreach ($this->result_map[$log_file] as $url => $count) {
               $tmp_file_content .= "\"{$count}\",\"{$url}\"\n";
            }
        }
        
        return $tmp_file_content;
    }    
    
    protected function get_tmp_file_path($log_file_key) {
        $pathinfo = pathinfo($this->log_file_list[$log_file_key]);
        return "{$this->tmp_dir}/{$pathinfo['basename']}_{$log_file_key}.csv";
    }
    
    protected function get_report_subject () {
        return '字节数较小页面';
    }
}
