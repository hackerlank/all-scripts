<?php
/**
 * 检测日志文件小于500的文件
 *
 */

$log_temp_arr = array();
$current_time = time();
$end_time = $current_time - 6 * 3600 + 180;
include_once(ROOT_PATH . "log/cls_abstract_log_checker.php");


class ReportLogChecker extends AbstractLogChecker {

    protected $report_mail_list = array(
#        'lchen@i9i8.com' => '陈磊',
#        'ychen@leqee.com' => '陈翼',
#        'yzhang@i9i8.com' => '张勇',
        'mxu2@i9i8.com' => '徐萌',
        'jhshi@i9i8.com' => '施剑辉',
    );
    
    public function check($line, $log_file_key) {
        preg_match('/\[(.*)\s+\-/isU', $line, $match); 
        global $current_time;
        global $end_time ;
        $strtime = strtotime(preg_replace("/([0-9]{4}):/i", '\\1 ', str_replace('/', ' ', $match[1])));
        if ($current_time > $strtime && $strtime < $end_time) {
            return;
        }
        $log_file = $this->log_file_list[$log_file_key];
        $parts = explode(' ', $line);
        if ($parts[5] == "\"GET"  // get请求
            && strpos($line, 'Googlebot') === false     // 去除google爬虫
            && strpos($line, 'monitor') === false     // 去除监控访问链接
            && strpos($parts[count($parts)-3], '-') === false     // 去除监控访问链接
            && strpos($parts[6], '/ajax.php') !== strlen($parts[6]) - 9 // 不以ajax.php的请求结尾，正常的请求都带参数
            && strpos($parts[6], '/newsletter_act.php') !== 0   // newsletter空白图片
            && strpos($parts[6], '/version') !== 0  // 版本信息
            && strpos($parts[6], '/crossdomain.xml') !== 0  // 非页面
            && strpos($parts[6], '/BingSiteAuth.xml') !== 0  // 非页面
            && strpos($parts[6], '/error.php') !== 0    // 正常错误页面是带参数的
            && strpos($parts[6], '/spacer.gif') === false   // 空白图片
            && strpos($parts[6], '/osticket') === false   // osticket
        ) {
            $str_arr = preg_split("/:/i", substr($parts[3], 1));
            $str_time = $str_arr['0'] . ':' .$str_arr['1'];
    #        print $parts[3]. " " . $parts[6] ." " .$parts[count($parts)-3] ."\n";
            $temp_arr = array('time' => $str_time, 'url' => $parts[6] , 'ip' => $parts[count($parts)-3]);
            global $log_temp_arr;
            $log_temp_arr[] = $temp_arr;
            $this->result_map[$log_file][$parts[6]]++;
        }
    }
    
    protected function get_report_content() {
        $report_content = "";
        foreach ($this->log_file_list as $log_file) {
            global $log_temp_arr;
	    $time_arr = array();
	    $count_arr = array();
            foreach ($log_temp_arr AS $t)
	    {
		$time_arr[] = $t['time'];
	    }
	    $time_arr = array_unique($time_arr);
	    foreach ($time_arr AS $v)
	    {
		foreach ($log_temp_arr AS $t)
		{
			if ($t['time'] == $v)
			{
				$count_arr[$v]['url'][] = $t['url'];
				if (preg_match("/cart.php/i", $t['url']))
				{
					$count_arr[$v]['cart_url'][] = $t['ip'];
				}
				$count_arr[$v]['ip'][] = $t['ip'];
			}
			
		}	
		
		$count_arr[$v]['ip']['count'] = count(array_unique($count_arr[$v]['ip']));
		$count_arr[$v]['cart_url']['count'] = count(array_unique($count_arr[$v]['cart_url']));
		$count_arr[$v]['url']['count'] = count(array_unique($count_arr[$v]['url']));
	    }
	    if (count($count_arr) < 6) {
                echo count($count_arr);
                exit;
            }
	    foreach ($count_arr AS $k => $v)
	    {
                $avg_url= sprintf("%.3f",$v['url']['count']/$v['ip']['count']);
                $cart_count= sprintf("%.3f",$v['cart_url']['count']/$v['ip']['count']);
		$report_content .= $k ."  全站访问ip数: {$v['ip']['count']}" .  "  全站访问页面数: {$v['url']['count']}" .  "  购物车访问ip数: {$v['cart_url']['count']}  ".  " 平均访问页面: $avg_url ".  " 购物车转化率: $cart_count\r\n" ;
            }
            $report_content .= "\n\n";
        }
            
        return $report_content;
    }
    
    protected function get_tmp_file_content($log_file_key) {
        $tmp_file_content = "";
        $log_file = $this->log_file_list[$log_file_key];
        if (is_array($this->result_map[$log_file])) {
            foreach ($this->result_map[$log_file] as $url => $count) {
               $tmp_file_content .= "\"{$count}\",\"{$url}\"\n";
            }
        }
        
        return $tmp_file_content;
    }    
    
    protected function get_report_subject () {
        return 'JenJenHouse稳定性报表';
    }
}
