<?php

include_once(ROOT_PATH . "log/cls_report_log_checker_all.php");

class LogChecker {
    private $log_file_list;
    private $result_map = array();
    private $checker_list = array();
    private $log_temp_arr;
    
    public function LogChecker($log_file_list) {
        if (!is_array($log_file_list)) {
            $log_file_list = array($log_file_list);
        }
        $this->log_file_list = $log_file_list;
    }
    
    public function check() {
        foreach ($this->log_file_list as $log_file_key => $log_file) {
            $fp = fopen($log_file, "r");
            while ($fp && !feof($fp)) {
                $line = fgets($fp);
                foreach ($this->checker_list as $checker) {
                    $checker->check($line, $log_file_key);
                }
            }
            fclose($fp);
        }
    }
    
    public function report() {
        foreach ($this->checker_list as $checker) {
            $checker->report();
        }
    }
    
    public function clear() {
        foreach ($this->checker_list as $checker) {
            $checker->clear();
        }
    }
    
    public function add_log_checker($check_name) {
        $log_checker_class = new ReflectionClass($check_name);
        $log_checker = $log_checker_class->newInstanceArgs(array($this->log_file_list));
        $this->checker_list[] = $log_checker;
    }
}
