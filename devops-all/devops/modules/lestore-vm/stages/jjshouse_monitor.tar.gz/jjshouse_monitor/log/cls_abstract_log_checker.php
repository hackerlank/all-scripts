<?php
/**
 * 检测日志日志的基类
 *
 */

include_once(ROOT_PATH . "includes/cls_alarm.php");

abstract class AbstractLogChecker {
    protected $log_file_list;
    protected $tmp_file_list;
    
    protected $tmp_dir = "/tmp";
    
    protected $result_map;
    protected $match_5xx_content;
    
    protected $report_mail_list;

    
    public function AbstractLogChecker($log_file_list) {
        $this->log_file_list = $log_file_list;
        
        foreach ($this->log_file_list as $log_file_key => $log_file) {
            if (is_file($log_file)) {
                $this->tmp_file_list[$log_file] = $this->get_tmp_file_path($log_file_key);
            } else {
                echo date('Y-m-d H:i:s') . ": log file error \"$log_file\"";
                $hostname = `hostname`;
                $alarm = new Alarm();
                $alarm->sendmail(2, "{$hostname}日志文件不存在{$log_file_key}", "{$argv[0]}\n{$hostname}\n日志文件不存在{$log_file}", $this->get_report_mail_list(), false, null);                
                die();
            }
        }
    }
    
    /**
     * 发送报告
     *
     */
    public function report() {
        if (!$this->is_report()) {
            return;
        }
        $this->write_tmp_file();
        
        $alarm = new Alarm();
        $alarm->sendmail($this->get_report_level(), $this->get_report_subject(), $this->get_report_content(), $this->get_report_mail_list(), false, $this->get_report_attachment_list());
        $alarm = new Alarm();
        $alarm->sendmail($this->get_report_level(), $this->get_report_subject(), $this->get_match_5xx_content(), $this->get_content_mail_list(), false, $this->get_report_attachment_list());
    }
    
    /**
     * 是否发送报告
     *
     * @return unknown
     */
    protected function is_report() {
        return true;
    }
    
    protected function write_tmp_file() {
        foreach ($this->log_file_list as $log_file_key => $log_file) {
            if ($this->tmp_file_list[$log_file]) {
                $fp = fopen($this->tmp_file_list[$log_file], "w+");
                fwrite($fp, $this->get_tmp_file_content($log_file_key));
                fclose($fp);
            }
        }
    }
    
    /**
     * 获取报告级别，默认为r
     *
     * @return int
     */
    protected function get_report_level() {
        return "r";
    }
    
    /**
     * 获取报告发送邮件列表
     *
     * @return array
     */
    protected function get_report_mail_list() {
        return $this->report_mail_list;
    }

    protected function get_content_mail_list() {
        return $this->content_mail_list;
    }
    
    /**
     * 获取报告附件列表
     *
     * @return array
     */
    protected function get_report_attachment_list() {
        $report_attachment_list = array();
        foreach ($this->tmp_file_list as $tmp_file) {
            if (is_file($tmp_file)) {
                $pathinfo = pathinfo($tmp_file);
                $report_attachment_list[$tmp_file] = $pathinfo['basename'];
            }
        }
        
        return $report_attachment_list;
    }
    
    /**
     * 获取临时文件的路径，用来做附件
     *
     */
    protected function get_tmp_file_path($log_file_key) {
        return null;
    }

    /**
     * 获取临时文件内容，用来做附件内容
     *
     */
    protected function get_tmp_file_content($log_file_key) {
        return null;
    }    
    
    /**
     * 临时数据清理
     *
     */
    public function clear() {
        foreach ($this->tmp_file_list as $tmp_file) {
            if (is_file($tmp_file)) {
                unlink($tmp_file);
            }
        }
    }
    
    /**
     * 检测的主要逻辑，输入一行日志，然后分析获取结果
     *
     * @param string $line
     */
    abstract protected function check($line, $log_file_key);
    
    /**
     * 获取报告内容
     *
     */
    abstract protected function get_report_content();

    protected function get_match_5xx_content() {
        return $this->match_5xx_content;
    }
    
    /**
     * 获取报告主题
     *
     */
    abstract protected function get_report_subject();
    
}
