<?php
/**
 * 检测日志文件小于500的文件
 *
 */

include_once(ROOT_PATH . "log/cls_abstract_log_checker.php");

class ErrorLogChecker extends AbstractLogChecker {

    protected $report_mail_list = array(
        'alarm@i9i8.com' => 'alarm',
    );

    protected $content_mail_list = array(
        'jhshi@i9i8.com' => '施剑辉',
        'yzhang@i9i8.com' => '张勇',
        'hwang@i9i8.com' => '王恒',
    );


    public function check($line, $log_file_key) {
        $filter_time = date("Y:H:", time() - 3600);
        if (strpos($line, $filter_time) === false) {
            return;
        }
        $log_file = $this->log_file_list[$log_file_key];
        $parts = explode(' ', $line);
        $http_code = $parts[8];
        $this->result_map[$log_file][$http_code]++;
        if (preg_match("/5../", $http_code)) {
            $this->match_5xx_content .= $line ;
        }
    }   
 
    protected function get_report_content() {
        $report_content = "";
        $hostname = `hostname`;
        foreach ($this->log_file_list as $log_file) {
            $report_content .= "$log_file response code count\n";
            $report_content .= "hostname $hostname\n";
            foreach ($this->result_map[$log_file] as $http_code => $count) {
                if (preg_match("/[0-9]{3}/", $http_code)){
                        $report_content .= "$http_code: {$count}\n";
                }
            }
            $report_content .= "\n\n";
        }

            
        return $report_content;
    }
    
    protected function get_report_subject () {
        $hostname = `hostname`;
        return "JenJenhouse 5xx {$hostname} 报警";
    }
    
    protected function is_report() {
        foreach ($this->result_map as $log_file => $result) {
            foreach ($result as $http_code => $count) {
                if (preg_match("/5../", $http_code) > 0) {
                    return true;
                }
            }
        }
        return false;
    }

    protected function get_report_level() {
        return "2";
    }    
}
