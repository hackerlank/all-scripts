#!/usr/bin/env python
# *.* coding : utf-8 *.*
#Created by vipwp

import urllib,urllib2,cookielib
import re,random,smtplib
import time,datetime,sys

class QQBizMail():
    def __init__(self,uid,pwd):
        i=uid.index('@')
        if i==-1:
            raise Exception('uid wrong~')
        self.uin=uid[:i]
        self.domain=uid[i+1:]
        self.inputuin=uid
        self.pwd=pwd
        
        self.aid='23000101'
        #self.PublicKey = "CF87D7B4C864F4842F1D337491A48FFF54B73A17300E8E42FA365420393AC0346AE55D8AFAD975DFA175FAF0106CBA81AF1DDE4ACEC284DAC6ED9A0D8FEB1CC070733C58213EFFED46529C54CEA06D774E3CC7E073346AEBD6C66FC973F299EB74738E400B22B1E7CDC54E71AED059D228DFEB5B29C530FF341502AE56DDCFE9"
        self.isConnected=False
    
    def login(self):
        cj = cookielib.CookieJar()
        self.opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
        self.opener.addheaders = [('User-agent', 'IE')]
        try:
            ret=self.opener.open("http://tel.exmail.qq.com/login")

            html=ret.read()
            #print html
            
            match=re.search(r'var PublicKey = "(.*?)"',html)
            if match:
                self.PublicKey=match.group(1)
                #print self.PublicKey            
            
            match=re.search(r'<input type="hidden" name="ts" value="(.*?)"',html)
            if match:
                self.ts=match.group(1)
                #print self.ts
            
            match=re.search(r'<input type="hidden" name="sid" value="(.*?)"/>',html)
            if match:
                self.sid=match.group(1)
                #print self.sid        
            
            match=re.search(r'<input type="hidden" name="s" value="(.*?)" />',html)
            if match:
                self.s=match.group(1)
                #print self.s   
                
            match=re.search(r'<input type="hidden" name="ppp" value="(.*?)" />',html)
            if match:
                self.ppp=match.group(1)
                #print self.ppp  
                
            match=re.search(r'<input type="hidden" name="loginentry" value="(.*?)" />',html)
            if match:
                self.loginentry=match.group(1)
                #print self.loginentry  
                
            match=re.search(r'<input type="hidden" name="fun" value="(.*?)" />',html)
            if match:
                self.fun=match.group(1)
                #print self.fun  
            
            match=re.search(r"<img id='vfcode' src='/cgi-bin/getverifyimage\?aid=(.*?)&",html)
            if match:
                self.aid=match.group(1)
                #print 'find:aid='+self.aid  
                
            ret=self.opener.open('http://tel.exmail.qq.com/cgi-bin/getverifyimage?aid=%s&%s'% \
                         (self.aid,random.random()) )
            self.verifyCode=ret.read()
            
            formData = urllib.urlencode( {
               'verifycode' : '',
               'uin'        : self.uin,
               'ts'         : self.ts,
               'starttime'  : str(int(time.mktime((datetime.datetime.now().timetuple())))),
               'sid'        : self.sid,
               's'          : self.s,
               'ppp'        : '',
               'pp'         : self.pwd,
               'p'          : self.getP(self.PublicKey,self.ts,self.pwd),
               'loginentry' : self.loginentry,
               'inputuin'   : self.inputuin,
               'fun'        : '',
               'form'       : '',
               'firstlogin' : 'false',
               'f'          : 'biz',
               'errtemplate': 'dm_loginpage',
               'domain'     : self.domain,
               'dmtype'     : 'bizmail',
               'delegate_url':'',
               'chg'        : '0',      
               'aliastype'  :'other'   
            })   
            
            ret=self.opener.open('https://tel.exmail.qq.com/cgi-bin/login',formData)
            html=ret.read()
            #print html
            
            match=re.search(r'targetUrl = urlHead \+ "frame_html\?sid=(.*?)";',html)
            if match:
                self.urlsid=match.group(1)
                #print self.urlsid
                
            match=re.search(r'targetUrl\+="&r=(.*?)";',html)
            if match:
                self.r=match.group(1)
                #print self.r
            
            self.opener.addheaders=[('Referer',ret.url)]
            self.isConnected=True
            
        except Exception as e:
            self.isConnected=False
            print str(e)
            return False        
            
    def getUsedSpace(self):
        if not self.isConnected:
            return False,'Need to login first~~'
         
        url='http://tel.exmail.qq.com/cgi-bin/today?sid=%s&nocheckframe=true'%self.urlsid
        try:
            ret=self.opener.open(url) 
            html=ret.read().decode('gbk').encode('utf-8')
            m=re.search(r'邮箱容量：<span>(.*?)</span>\(已使用：<span>(.*?)</span>，(.*?)\)',html)
            if m:
                #print m.group(0)
                return True,[m.group(1),m.group(2),m.group(3)]
            else:
                return False,'Failed to read the webpage~~'
        except Exception as e:
            return False,str(e)
            
    def getP(self,publicRsaKey,ts,pp):
        import rsa,base64
        rsaPublickey = int(publicRsaKey, 16)
        key = rsa.PublicKey(rsaPublickey, int('10001',16))
        msg=rsa.encrypt(pp+'\n'+ts+'\n',key)
        msg64=base64.b64encode(msg)
        return msg64     
    

email = sys.argv[1]   #监控的邮箱账号
pwd = sys.argv[2]    #监控的邮箱密码
to_email = sys.argv[3]   #接收报警的邮箱

s=QQBizMail(email, pwd)
s.login()
r,space = s.getUsedSpace()
if r:
    print email, space
    useage = space[2].endswith('%') and int(space[2].rpartition('%')[0])
    if useage >= 80:
       session = smtplib.SMTP('smtp.exmail.qq.com', 25)
       session.login(email, pwd)
       headers = "\r\n".join(["from: " + email , "subject:[Sev-2] %s 邮箱空间(%s)已使用: %s"%(email, space[0], space[2]), "to: " + to_email, "mime-version: 1.0", "content-type: text/html"])
       content = headers + "\r\n\r\n" + email + " 邮箱空间已使用:" + space[2]
       session.sendmail(email, to_email, content)
       print "send ok"